package com.jayus.onjava.six;

/**
 * @author : h zk
 * @date : 2022/7/14 16:13
 * @description :
 **/
public enum Spiciness {
    NOT,MILD,MEDIUM,HOT,FLAMING
}
