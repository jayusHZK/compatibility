package com.jayus.onjava.six;

/**
 * @author : h zk
 * @date : 2022/7/14 16:14
 * @description :
 **/
public class Test {
    public static void main(String[] args) {
        for(Spiciness item : Spiciness.values()){
            System.out.println(item + ",Spiciness " + item.ordinal());
        }
    }
    {
        System.out.println(111);
    }
}
