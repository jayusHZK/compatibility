package com.jayus.onjava.thirteen.RunnableMethodReference;

/**
 * @author : h zk
 * @date : 2022/7/19 10:28
 * @description :
 **/
public class Go {
    static void go(){
        System.out.println("Go::go()");
    }
}
