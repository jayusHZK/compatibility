package com.jayus.onjava.thirteen.seriorFunction;

/**
 * @author : h zk
 * @date : 2022/7/21 11:32
 * @description :
 **/
public class I {
    @Override
    public String toString() {
        return "I";
    }
}
