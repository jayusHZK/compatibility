package com.jayus.onjava.thirteen.methodReference;

/**
 * @author : h zk
 * @date : 2022/7/19 9:53
 * @description :
 **/
public class Describe {
    void show(String s){
        System.out.println("Describe.show:"+s);
    }
}
