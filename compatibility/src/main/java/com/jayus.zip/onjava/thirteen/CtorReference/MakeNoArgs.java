package com.jayus.onjava.thirteen.CtorReference;

/**
 * @author : h zk
 * @date : 2022/7/19 11:17
 * @description :
 **/
public interface MakeNoArgs {
    Dog make();
}
