package com.jayus.onjava.thirteen.functional;

/**
 * @author : h zk
 * @date : 2022/7/19 11:32
 * @description :
 **/
public interface FunctionalNoAnn {
    String goodbye(String arg);
}
