package com.jayus.onjava.thirteen.seriorFunction;

/**
 * @author : h zk
 * @date : 2022/7/21 11:31
 * @description :
 **/
public class O {
    @Override
    public String toString() {
        return "O";
    }
}
