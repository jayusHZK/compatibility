package com.jayus.onjava.thirteen.functional;

import jdk.nashorn.internal.objects.annotations.Function;

/**
 * @author : h zk
 * @date : 2022/7/19 11:30
 * @description :
 **/
@FunctionalInterface
public interface Functional {
    String goodbye(String arg);
}
