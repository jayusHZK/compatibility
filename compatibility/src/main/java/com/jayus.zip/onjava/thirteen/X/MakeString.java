package com.jayus.onjava.thirteen.X;

/**
 * @author : h zk
 * @date : 2022/7/19 10:37
 * @description :
 **/
public interface MakeString {
    String make();
}
