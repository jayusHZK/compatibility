package com.jayus.onjava.thirteen.CtorReference;

/**
 * @author : h zk
 * @date : 2022/7/19 11:19
 * @description :
 **/
public interface Make2Args {
    Dog make(String nm,int yrs);
}
