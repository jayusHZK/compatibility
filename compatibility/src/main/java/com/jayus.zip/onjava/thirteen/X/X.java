package com.jayus.onjava.thirteen.X;

/**
 * @author : h zk
 * @date : 2022/7/19 10:36
 * @description :
 **/
public class X {
    String f() {
        return "X::f()";
    }
}
