package com.jayus.onjava.thirteen.methodReference;

/**
 * @author : h zk
 * @date : 2022/7/19 9:52
 * @description :
 **/
public interface Callable {
    void call(String s);
}
