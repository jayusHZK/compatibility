package com.jayus.onjava.thirteen.X;

/**
 * @author : h zk
 * @date : 2022/7/19 10:38
 * @description :
 **/
public interface TransformX {
    String tranform(X x);
}
