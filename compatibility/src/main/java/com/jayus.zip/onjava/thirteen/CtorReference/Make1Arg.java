package com.jayus.onjava.thirteen.CtorReference;

/**
 * @author : h zk
 * @date : 2022/7/19 11:18
 * @description :
 **/
public interface Make1Arg {
    Dog make(String name);
}
