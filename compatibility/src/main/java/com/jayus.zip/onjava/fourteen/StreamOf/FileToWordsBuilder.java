package com.jayus.onjava.fourteen.StreamOf;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

/**
 * @author : h zk
 * @date : 2022/7/27 14:01
 * @description :
 **/
public class FileToWordsBuilder {
    Stream.Builder<String> builder = Stream.builder();

    public FileToWordsBuilder() throws IOException {
        Files.readAllLines(Paths.get("C:\\Users\\sinozo\\Desktop\\2.txt"))
                .stream().skip(1)
                .forEach(line -> {
                    for (String word : line.split("[ .?,]"))
                        builder.add(word);
                });
    }

    Stream<String> stream(){
        return builder.build();
    }

    public static void main(String[] args) throws IOException {
        new FileToWordsBuilder()
                .stream()
                .limit(7)
                .map( w -> w+ " ")
                .forEach(System.out::println);
    }
}
