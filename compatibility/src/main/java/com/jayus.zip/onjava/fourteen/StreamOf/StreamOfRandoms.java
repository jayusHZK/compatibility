package com.jayus.onjava.fourteen.StreamOf;

import java.util.Random;
import java.util.stream.IntStream;
import java.util.stream.Stream;

/**
 * @author : h zk
 * @date : 2022/7/27 17:09
 * @description :
 **/
public class StreamOfRandoms {
    static Random rand = new Random(47);

    public static void main(String[] args) {
        Stream.of(1,2,3,4,5)
                .flatMapToInt(i -> IntStream.concat(rand.ints(0,100).limit(i),IntStream.of(-1)))
                .forEach(System.out::println);
    }
}
