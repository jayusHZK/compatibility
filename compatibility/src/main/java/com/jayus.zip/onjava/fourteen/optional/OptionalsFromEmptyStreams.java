package com.jayus.onjava.fourteen.optional;

import java.util.stream.IntStream;
import java.util.stream.Stream;

/**
 * @author : h zk
 * @date : 2022/7/27 17:21
 * @description :
 **/
public class OptionalsFromEmptyStreams {
    public static void main(String[] args) {
        System.out.println(Stream.<String>empty().findFirst());
        System.out.println(Stream.<String>empty().findAny());
        System.out.println(Stream.<String>empty().max(String.CASE_INSENSITIVE_ORDER));
        System.out.println(Stream.<String>empty().reduce((s1, s2) -> s1 + s2));
        System.out.println(IntStream.empty().average());
    }
}
