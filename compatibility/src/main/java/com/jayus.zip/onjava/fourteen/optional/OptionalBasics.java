package com.jayus.onjava.fourteen.optional;

import java.util.Optional;
import java.util.stream.Stream;

/**
 * @author : h zk
 * @date : 2022/7/27 17:31
 * @description :
 **/
public class OptionalBasics {
    static void test(Optional<String> optString){
        if (optString.isPresent())
            System.out.println(optString.get());
        else
            System.out.println("Nothing inside");
    }

    public static void main(String[] args) {
        test(Stream.of("a").findFirst());
        test(Stream.<String>empty().findFirst());
    }
}
