package com.jayus.onjava.fourteen.StreamOf;

import java.util.stream.Stream;

/**
 * @author : h zk
 * @date : 2022/7/27 17:04
 * @description :
 **/
public class StreamOfStreams {
    public static void main(String[] args) {
        Stream.of(1,2,3)
                .map(i -> Stream.of("a","b","c"))
                .map(e -> e.getClass().getName())
                .forEach(System.out::println);
    }
}
