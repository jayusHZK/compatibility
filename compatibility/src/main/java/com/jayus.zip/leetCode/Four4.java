package com.jayus.leetCode;

/**
 * @author : h zk
 * @date : 2022/7/5 16:05
 * @description : 得到两个有序数组合并后的中位数
 **/
public class Four4 {
    public static void main(String[] args) {
        Integer[] arr1 = new Integer[]{1,4,9,12};
        Integer[] arr2 = new Integer[]{2,3,5,8,10};
    }

    public Double findMedianSortedArrays(Integer[] arr1, Integer[] arr2) {
        int mid = (arr1.length + arr2.length) / 2;
        int cur = 0;
        while (cur <= mid){
            return 2D;
        }
        return 1D;
    }
}
