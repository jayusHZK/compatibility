package com.jayus.ThreadPool;

/**
 * @author : h zk
 * @date : 2022/7/7 16:35
 * @description :
 **/
public class ThreadTest {
    public static void main(String[] args) {
        new Thread(() ->{

        });
    }
}
